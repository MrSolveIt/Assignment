namespace Data_Model.DbWork
{
    public interface IDbWork
    {
        /// <summary>
        /// Save method.
        /// </summary>
        void Save();
    }
}