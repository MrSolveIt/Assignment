﻿using System.ComponentModel.Composition;
using Data_Model.DbWork;
using Resolver;

namespace Data_Model
{
    [Export(typeof(IComponent))]
    public class DependencyResolver : IComponent
    {
        public void SetUp(IRegisterComponent registerComponent)
        {
            registerComponent.RegisterType<IDbWork, DbWork.DbWork>();
        }
    }
}
