﻿using Entities;
using System;
using System.Collections.Generic;

namespace Services
{
    /// <summary>
    /// NewsContent Service Contract
    /// </summary>
    public interface INewsContentServices
    {
        IEnumerable<Items> GetNewsContentBySearch(string search);
        IEnumerable<TEntity> GetCachedData<TEntity>(string key, Func<IEnumerable<TEntity>> valueFactory,int CacheExpiry) where TEntity : class;
    }
}
