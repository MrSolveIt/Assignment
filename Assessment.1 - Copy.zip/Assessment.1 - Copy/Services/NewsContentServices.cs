﻿using Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Caching;
using System.Text;

namespace Services
{
    /// <summary>
    /// Offers services
    /// </summary>
    public class NewsContentServices:INewsContentServices
    {
        public IEnumerable<Items> GetNewsContentBySearch(string search)
        {
            var response = new List<Items>();
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create($"http://news.google.com/news?q=" + search + "&output=rss");
            request.Method = "GET";
            var results = (HttpWebResponse)request.GetResponse();
            if (results.StatusCode == HttpStatusCode.OK)
            {
                Stream receiveStream = results.GetResponseStream();
                StreamReader readStream = null;
                if (results.CharacterSet == "")
                {
                    readStream = new StreamReader(receiveStream);
                }
                else
                {
                    readStream = new StreamReader(receiveStream, Encoding.GetEncoding(results.CharacterSet));
                }
                using (StringReader reader = new StringReader(readStream.ReadToEnd()))
                {
                    DataSet ds = new DataSet();
                    ds.ReadXml(reader);
                    DataTable dt_GetNews = new DataTable();
                    if (ds != null && ds.Tables.Count > 3)
                    {
                        dt_GetNews = ds.Tables["item"];
                        foreach (DataRow dtRow in dt_GetNews.Rows)
                        {
                            response.Add(new Items()
                            {
                                Title = dtRow["title"].ToString(),
                                Link = dtRow["link"].ToString(),
                                Description = dtRow["description"].ToString(),
                                PubDate = dtRow["pubDate"].ToString()
                            });
                        }
                    }
                }
            }
            return response.AsEnumerable();
        }
        /// <summary>
        /// Cache searched news content.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<TEntity> GetCachedData<TEntity>(string key, Func<IEnumerable<TEntity>> valueFactory,int CacheExpiry) where TEntity : class
        {
            ObjectCache cache = MemoryCache.Default;
            var newValue = new Lazy<IEnumerable<TEntity>>(valueFactory);
            CacheItemPolicy policy = new CacheItemPolicy { AbsoluteExpiration = DateTimeOffset.Now.AddMinutes(CacheExpiry) };
            //The line below returns existing item or adds the new value if it doesn't exist
            var value = cache.AddOrGetExisting(key.Trim().ToLower(), newValue, policy) as Lazy<IEnumerable<TEntity>>;
            return (value ?? newValue).Value; // Lazy<T> handles the locking itself
        }
    }
}
