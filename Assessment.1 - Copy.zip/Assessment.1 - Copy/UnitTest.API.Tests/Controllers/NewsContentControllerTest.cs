﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebApi.Controllers;

namespace UnitTest.API.Tests.Controllers
{
    [TestClass]
    public class NewsContentControllerTest
    {
        [TestMethod]
        public void GetNewsContentBySearch()
        {
            // Arrange
            NewsContentController controller = new NewsContentController(null);

            // Act
            var result = controller.GetNewsContent("jhb");
            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(HttpStatusCode.OK, result.StatusCode);
            Assert.AreEqual(true, result.IsSuccessStatusCode);
        }
    }
}
