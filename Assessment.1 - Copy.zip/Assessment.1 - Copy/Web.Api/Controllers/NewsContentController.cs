﻿
using System.Configuration;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AttributeRouting;
using AttributeRouting.Web.Http;
using Services;
using WebApi.ActionFilters;

namespace WebApi.Controllers
{
    [AuthorizationRequired]
    [RoutePrefix("v1/News/Content")]
    public class NewsContentController : ApiController
    {
        #region Private variable.

        private readonly INewsContentServices _newscontentServices;
        #endregion

        #region Public Constructor

        /// <summary>
        /// Public constructor to initialize News Content service instance
        /// </summary>
        public NewsContentController(INewsContentServices newscontentServices)
        {
            _newscontentServices = newscontentServices;
        }

        #endregion
        // GET api/NewsContent/5
        [GET("NewsContent/{Search?}")]
        //[CacheClient(Duration = 100)]
        //[OutputCache(Duration = 100)]
        public HttpResponseMessage GetNewsContent(string Search)
        {
            var News = _newscontentServices.GetCachedData(Search, () => _newscontentServices.GetNewsContentBySearch(Search),int.Parse(ConfigurationManager.AppSettings["CacheExpiry"]));
            if (News != null)
                return Request.CreateResponse(HttpStatusCode.OK, News);
            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "No news content found for this search");
        }
    }
}
