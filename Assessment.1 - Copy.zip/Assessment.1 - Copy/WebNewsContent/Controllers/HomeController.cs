﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using WebNewsContent.Models;

namespace WebNewsContent.Controllers
{
    public class HomeController : Controller
    {
        private IConfiguration configuration;
        string Baseurl = "http://localhost:55959/";
        public HomeController(IConfiguration iConfig)
        {
            configuration = iConfig;
        }
        public async Task<ActionResult> Index(string Search = "jhb")
        {
            //login
            var NewsContent = new List<Items>();
            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("Token", configuration.GetValue<string>("AppSettings:Token"));
                
                //Sending request to find web api REST service resource GetNewsContent using HttpClient  
                var response = await client.GetAsync("v1/News/Content/NewsContent/" + Search);

                //Checking the response is successful or not which is sent using HttpClient  
                if (response.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var Itemsresponse = response.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the list  
                    NewsContent = JsonConvert.DeserializeObject<List<Items>>(Itemsresponse);
                }
            }
            return View(NewsContent);
        }
    }
}
